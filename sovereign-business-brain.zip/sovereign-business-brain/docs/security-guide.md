
# Security Guide

- Google OAuth 2.0
- JWT Authentication
- HTTPS SSL
- AWS Secrets Manager
- AES Encryption
- Secure Pinecone Namespaces
