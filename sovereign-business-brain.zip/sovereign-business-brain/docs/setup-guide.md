
# Setup Guide

## Frontend
cd frontend
npm install
npm run dev

## Backend
cd backend
npm install
npm run dev

## Database
Run PostgreSQL and apply Prisma migrations.
