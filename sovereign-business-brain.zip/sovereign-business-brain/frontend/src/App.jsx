
export default function App() {
  return (
    <div style={{padding: '40px', color: 'white', background: '#111', minHeight: '100vh'}}>
      <h1>Sovereign Business Brain</h1>
      <p>AI-Powered Autonomous Business Operating System</p>
    </div>
  );
}
